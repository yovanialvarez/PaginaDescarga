<!DOCTYPE html>
<html lang="es">

<head>
	<link rel="stylesheet"  href="css/estilos.css">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link href="css/style4.css" rel="stylesheet"/>
	<title>Home</title>
</head>
<body background="pictures/picture11.jpg" bgproperties="fixed">
	<?php
		session_start();
		$busqueda=$_GET['var'];

		if (empty($_SESSION)&&empty($busqueda)) {
			header("location: homee.php?var=0");
		}

		$conection=mysql_connect('localhost','root');
		mysql_select_db('files',$conection);

		if (empty($_SESSION['login'])&&($busqueda==0)){
			$Vuser=$_POST['user'];
			$Vpass=$_POST['pass'];

			$consulta="SELECT *FROM  usuario where Usuario='$Vuser' and Password='$Vpass'";

			$datos = mysql_query($consulta);
			$usuario =mysql_fetch_row($datos);

			if($usuario[0]>0){
				$_SESSION['login']=1;
				$_SESSION['nombre']=$usuario[1];
			}
		}

		if ($_SESSION['login']==1) {
// if login==0  ===============================================================================================================================================
		?>
				<nav>
				    <ul>
				    	<li><img src="pictures/picture2.jpg"border="0" width="65" height="40"></li>
				        <li>
				            <a href="home.php"><h4><?php echo $_SESSION['nombre']; ?> </h4></a>
				            <ul>
				                <li><a href="homee.php?var=1"><h4> Cerrar Sesion</h4></a></li>
				            </ul>
				        </li>
				        <li >
				            <a href="upphoto.php ? var=0"><h4>Subir Imagenes</h4></a>
				        </li>
				        <li >
				            <a href="upmusic.php ? var=0"><h4>Subir Musica</h4></a>
				        </li>

				        <li><a href="upvideo.php ? var=0"><h4>Subir Videos</h4></a></li>
				    </ul>
				</nav>

				</br> </br>
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-3">
							<table>
								<tr>
									<td>
										<img src="pictures/picture15.jpg"border="0" width="150" height="100">
									</td>
								</tr>
							</table>			
						</div>
			<!-- ==================================================================================================================== -->
						<div class="col-md-6">
							<form action="home.php ? var=1" method="POST">
								<table class="table table-striped" >
									<tr>
										<td>
											<label>Buscar archivo</label>
										</td>
										<td>
											<input type="text" name="txtbuscar" value="buscar" size="15" onclick="if(this.value=='buscar') this.value=''" onblur="if(this.value=='') this.value='buscar'">
										</td>
										<td>
											<select name="option" onChange="combo(this, 'theinput')">
												<option value="Musica">Musica</option>
											  	<option value="Videos">Video</option>
											  	<option value="Fotos">Photo</option>
											</select>
										</td>
										<td>
											<input type="submit" value="Buscar">
										</td>
									</tr>

								</table>					
							</form>			
						</div>
			<!-- ==================================================================================================================== -->
						
					</div>		
				</div>			
				<?php
				if($busqueda==1){
				// if busqueda==1 ===============================================================================================================================================
					$buscar =$_POST['txtbuscar'];
					$op =$_POST['option'];

					$consulta ="SELECT * FROM $op where nombre like '$buscar%'"; 

					$archivos = mysql_query($consulta);
				?>
					<div class="container-fluid">
						<div class="row">
							<div class="col-md-3"></div>
							<div class="col-md-6">
								<table  class="table table-striped" >
								
								<?php
								if ($op =='Fotos'){
								?>
									<tr>
										<th> Nombre	</th>	
										<th></th>				
										<th>Descargar</th>
									</tr>				
									<?php
										while ($record=mysql_fetch_row($archivos)) {
									
									?>
									<tr>
										<th><?php echo $record[1];?></th>
										<td><img src="<?php echo $record[2]; ?> " border="0" width="50" height="35"></td>
										<th> <a href="<?php echo $record[2]; ?>">Descargar</a>  </th>
									</tr>
									<?php
									}
								}
									?>
				<!-- ===================================================================================== -->
								<?php
								if (($op == 'Musica')||($op =='Videos')){
								?>
									<tr>
										<th> Nombre	</th>					
										<th>Artista</th>
										<th>Album</th>
										<th>Descargar</th>
									</tr>
								<?php
									while ($record=mysql_fetch_row($archivos)) {
								?>
									<tr>
										<td><?php echo $record[1];?></td>
										<td><?php echo $record[2];?></td>
										<td><?php echo $record[3];?></td>
										<td>  <a href="<?php echo $record[4]; ?>">Descargar</a>  </td>
									</tr>
									<?php
									}
								}
									?>
				<!-- ===================================================================================== -->					
								</table>			
							</div>
							
						</div>
					</div>

				<?php
				// End if Busqueda ==============================================================================================================================================
				}
			?>
		<?php
// End if login==0  =============================================================================================================================================		
		}
		else{
				header("location: login.php?var=0");
		}
?>


</body>
</html>
