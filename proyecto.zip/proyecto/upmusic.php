<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">	
	<title>Cargar Musica</title>
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrapValidator.min.js"></script>
	<script src="js/noty.js"></script>
	<script src="js/app.js"></script>
</head>
<body background="pictures/picture11.jpg" bgproperties="fixed">
<?php
	$var=$_GET['var'];
	session_start();

	if ($_SESSION['login']==1){

		if ($var==0){
			?>

				<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">

			    <div id="login-overlay" class="modal-dialog">
			      <div class="modal-content">
			          <div class="modal-header">
			              <center><h4 class="modal-title" id="myModalLabel">Subir Musica</h4></center>
			          </div>
			          <div class="modal-body">
			              <div class="row">
			                  <div class="col-xs-11">
			                      <div class="well">
			                          <form  action="upmusic.php ? var=1" method="POST" enctype="multipart/form-data" id="form-login">
			                              <div class="form-group">
			                              	<table class="table" >
													<tr>
														<th>Nombre</th>
														<th><input type="text" name="txtnombre" class="form-control"></th>
													</tr>

													<tr>
														<th>Artista</th>
														<th><input type="text" name="txtartista" class="form-control"></th>
													</tr>
													
													<tr>
														<th>Genero</th>
														<th><input type="text" name="txtgenero" class="form-control"></th>
													</tr>

													<tr>
														<td><input type="file" name="nombreM" style="width:95px"></td>
													</tr>

				                            </table>
			                              </div>                              
			                              <input type="submit" name="btnguardar" class="btn" value="Guardar">
			                          </form>
			                      </div>
			                  </div>
			<!-- =================================================================================================================================== -->

			<!-- =================================================================================================================================== -->
			              </div>
			          </div>
			      </div>
			  	</div>
		  		</br>	

			<?php
		
		}
		else
		{

			if (isset($_POST['btnguardar'])) {
				$archivo = $_FILES['nombreM']['tmp_name'];
				$destino = "cargas/Music/". $_FILES['nombreM']['name'];

				move_uploaded_file($archivo, $destino);

				$nombre =$_POST['txtnombre'];
				$artista =$_POST['txtartista'];
				$genero =$_POST['txtgenero'];

				$conection =mysql_connect('localhost','root');

				if (mysql_select_db("Files",$conection))
					echo "Conectado";
				else
					echo "error al conectar";
				
				if(empty($nombre) || empty($artista) || empty($genero)){
					header("location: upmusic.php?var=0");
				}
				else{
					$consulta ="INSERT INTO Musica(nombre,artista,genero,ruta) VALUES('$nombre','$artista','$genero','$destino')";
					echo $consulta;

					if (mysql_query($consulta))
						echo "Insercion Correcta";
					else
						echo "Error al insertar";
				}
			}
			?>
			<form action="home.php ? var=0" method="POST">
				<button type="submit" class="btn ">Volver a la pagina</button>
			</form			
			<?php
		}
	}
	else{
		header("location: login.php?var=0");
	}
?>

</body>
</html>
