<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">	
	<title>Cargar Imagen</title>
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrapValidator.min.js"></script>
	<script src="js/noty.js"></script>
	<script src="js/app.js"></script>
</head>
<body background="pictures/picture11.jpg" bgproperties="fixed">
<?php
	$var=$_GET['var'];
	session_start();

	if ($_SESSION['login']==1){

		if ($var==0){
			?>

				<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">

			    <div id="login-overlay" class="modal-dialog">
			      <div class="modal-content">
			          <div class="modal-header">
			              <center><h4 class="modal-title" id="myModalLabel">Subir Imagen</h4></center>
			          </div>
			          <div class="modal-body">
			              <div class="row">
			                  <div class="col-xs-10">
			                      <div class="well">
			                          <form  action="upphoto.php ? var=1" method="POST" enctype="multipart/form-data" id="form-login">
			                              <div class="form-group">
			                              	<table class="table">
				                              	<tr>
				                              		<th>Nombre</th>
					                                <th><input type="text" name="txtnombre" class="form-control"></th>
					                            </tr>
					                            <tr> 
					                                <td><input type="file" name="nombreP" style="width:95px"></td>
					                                  <span class="help-block"></span>
					                            </tr>
				                            </table>
			                              </div>                              
			                              <input type="submit" name="btnguardar" class="btn" value="Guardar">
			                          </form>
			                      </div>
			                  </div>
			<!-- =================================================================================================================================== -->

			<!-- =================================================================================================================================== -->
			              </div>
			          </div>
			      </div>
			  	</div>
		  		</br>	

			<?php
		
		}
		else
		{

			if (isset($_POST['btnguardar'])) {
				$archivo = $_FILES['nombreP']['tmp_name'];
				$destino = "cargas/Photo/". $_FILES['nombreP'] ['name'];

				move_uploaded_file($archivo, $destino);

				$nombre = $_POST['txtnombre'];
				$conection =mysql_connect('localhost','root');

				if (mysql_select_db("Files",$conection))
					echo "Conectado";
				else
					echo "Error al conectar";

				if (empty($nombre)){
					header("location: upphoto.php?var=0");
				}
				else{
					$consulta="INSERT INTO Fotos(nombre,ruta) VALUES('$nombre','$destino')";
					echo $consulta;

					mysql_query($consulta);
				}
			}
			?>
			<form action="home.php ? var=0" method="POST">
				<button type="submit" class="btn ">Volver a la pagina</button>
			</form			
			<?php
		}
	}
	else{
		header("location: login.php?var=0");
	}
?>

</body>
</html>



