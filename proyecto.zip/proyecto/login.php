<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">	
	<title>Iniciar Sesion</title>
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrapValidator.min.js"></script>
	<script src="js/noty.js"></script>
	<script src="js/app.js"></script>
</head>
<body background="pictures/picture11.jpg" bgproperties="fixed">
<?php
  $var=$_GET['var'];
  
	session_start();
  if (empty($_SESSION['login'])){

  }
  else{
    header("location: home.php?var=0");
  }
//	$_SESSION['login']=0;

  if ($var==1){
    $Nombre=$_POST['nombre'];
    $Apellido=$_POST['apellido'];
    $Correo=$_POST['correo'];
    $Usuario=$_POST['usuario'];
    $Password=$_POST['password'];
    if(empty($Nombre) || empty($Apellido) || empty($Correo) || empty($usuario) || (empty($Password))){
        header("location: registrar.php");
    }
    else{
        $conection =mysql_connect('localhost','root');
        mysql_select_db("Files",$conection);

        $consulta ="INSERT INTO usuario (Nombre,Apellido,Correo,Usuario,Password) Values('$Nombre','$Apellido','$Correo','$Usuario','$Password')"; 

        mysql_query($consulta);
    }
  }
?>
	<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
  </br></br>
    <div  class="container-fluid">
      <div class="modal-content">
          <div class="modal-header">
              <center><h4 class="modal-title" id="myModalLabel">Iniciar</h4></center>
          </div>
          <div class="modal-body">
              <div class="row">
                <div class="col-xs-4"><img src="pictures/picture4.jpg " width="526" height="396"></div>
                <div class="col-xs-1"></div>
                  <div class="col-xs-4">
                      <div class="well">
                          <form  action="home.php ? var=0" method="POST" id="form-login">
                              <div class="form-group">
                                  <label for="usuario" class="control-label">Usuario</label>
                                  <input type="text" name="user" class="form-control">
                                  
                              </div>

                              <div class="form-group">
                                  <label for="password" class="control-label">Password</label>
                                  <input type="password" class="form-control" id="password" name="pass">
                                  <!-- <span class="help-block"></span> -->
                              </div>
                                <table class="table">
                                  <tr>
                                    <th><a href="recuperar.php">Olvidaste tu constraseña</a></th>
                                    <th><a href="registrar.php">Registrate Ahora</a></th>
                                  </tr>
                                </table>
                              <button type="submit" class="btn btn-success btn-block">Ingresar</button>
                          </form>
                      </div>
                  </div>
<!-- =================================================================================================================================== -->

<!-- =================================================================================================================================== -->
              </div>
          </div>
      </div>
  </div>

</body>
</html>