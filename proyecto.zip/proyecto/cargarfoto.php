<?php
	session_start();

	if ($_SESSION['login']==1){
			if (isset($_POST['btnguardar'])) {
				$archivo = $_FILES['nombreP']['tmp_name'];
				$destino = "cargas/Photo/". $_FILES['nombreP'] ['name'];

				move_uploaded_file($archivo, $destino);

				$nombre = $_POST['txtnombre'];
				$conection =mysql_connect('localhost','root');

				if (mysql_select_db("Files",$conection))
					echo "Conectado";
				else
					echo "Error al conectar";

				$consulta="INSERT INTO Fotos(nombre,ruta) VALUES('$nombre','$destino')";
				echo $consulta;

				mysql_query($consulta);

			}
	}
	else{
		header("location: login.php?var=0");
	}
?>