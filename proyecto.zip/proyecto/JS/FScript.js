$(document).on('ready',Inicio);

function Inicio(){
	$('#btnregistro1').on('click',Evaluar);
}

function Evaluar(){
	var Vnombre=$('#txtnombre').val();
	var Vapellido=$('#txtapellido').val();
	var Vcorreo=$('#txtcorreo').val();
	var Vuser=$('#txtuser').val();
	var Vpass=$('#txtpass').val();

	if ((Vnombre != "") && (Vapellido !="") && ( Vcorreo !="") && (Vuser !="") && ( Vpass !="")) {
		$.ajax({
			url:"procesar.php?var=1",
			type:'POST',
			data:{txtnombre:Vnombre, txtapellido:Vapellido, txtcorreo:Vcorreo, txtuser:Vuser, txtpass:Vpass},
		});
		alert("datos ingresados correctamente");
	}
	else{	
		alert("Error llene todos los campos");
		
	};
}


