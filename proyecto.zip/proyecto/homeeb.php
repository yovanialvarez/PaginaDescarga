<!DOCTYPE html>
<html lang="es">

<head>
	<link rel="stylesheet"  href="css/estilos.css">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link href="css/style4.css" rel="stylesheet"/>
	<title>Home</title>
</head>
<body background="pictures/picture11.jpg" bgproperties="fixed">

	<?php
	session_start();
	if (empty($_SESSION['login'])) {
		
	}
	else
		header("location: home.php?var=0");

	$buscar =$_POST['txtbuscar'];
	$op =$_POST['option'];

	if (empty($buscar)&& empty($op)) {
		header("location: homee.php");
	}

	$conection =mysql_connect('localhost','root');
	mysql_select_db("Files",$conection);

	$consulta ="SELECT * FROM $op where nombre like '$buscar%'"; 

	$archivos = mysql_query($consulta);

	?>
<!--<body background="pictures/fondo5.jpg">  -->
	<nav>
	    <ul>
	        <li>
	            <a href="registrar.php"><h4>Registrate</h4> </a>
	        </li>
	        <li >
	            <a href="login.php?var=0"><h4>Accede a tu cuenta</h4></a>
	        </li>

	    </ul>
	</nav>
	</br> </br>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-3">
				<table>
					<tr>
						<td>
							<img src="pictures/picture15.jpg"border="0" width="150" height="100">
						</td>
					</tr>
				</table>			
			</div>
<!-- ==================================================================================================================== -->
			<div class="col-md-6">
				<form action="homeeb.php" method="POST">
					<table class="table table-striped" >
						<tr>
							<td>
								<label>Buscar archivo</label>
							</td>
							<td>
								<input type="text" name="txtbuscar" value="buscar" size="15" onclick="if(this.value=='buscar') this.value=''" onblur="if(this.value=='') this.value='buscar'">
							</td>
							<td>
								<select name="option" onChange="combo(this, 'theinput')">
									<option value="Musica">Musica</option>
								  	<option value="Videos">Video</option>
								  	<option value="Fotos">Photo</option>
								</select>
							</td>
							<td>
								<input type="submit" value="Buscar">
							</td>
						</tr>

					</table>					
				</form>			
			</div>
<!-- ==================================================================================================================== -->
		</div>		
	</div>
<!-- ==================================================================================================================== -->

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6">
				<table  class="table table-striped" >
				
				<?php
				if ($op =='Fotos'){
				?>
					<tr>
						<th> Nombre	</th>	
						<th></th>				
						<th>Descargar</th>
					</tr>				
					<?php
						while ($record=mysql_fetch_row($archivos)) {
					
					?>
					<tr>
						<th><?php echo $record[1];?></th>
						<td><img src="<?php echo $record[2]; ?> " border="0" width="50" height="35"></td>
						<th>  <a href="<?php echo $record[2]; ?>">Descargar</a>  </th>
					</tr>
					<?php
					}
				}
					?>
<!-- ===================================================================================== -->
				<?php
				if (($op == 'Musica')||($op =='Videos')){
				?>
					<tr>
						<th> Nombre	</th>					
						<th>Artista</th>
						<th>Album</th>
						<th>Descargar</th>
					</tr>
				<?php
					while ($record=mysql_fetch_row($archivos)) {
				?>
					<tr>
						<td><?php echo $record[1];?></td>
						<td><?php echo $record[2];?></td>
						<td><?php echo $record[3];?></td>
						<td>  <a href="<?php echo $record[4]; ?>">Descargar</a>  </td>
					</tr>
					<?php
					}
				}
					?>
<!-- ===================================================================================== -->					
				</table>			
			</div>
			
		</div>
	</div>
<!-- ==================================================================================================================== -->
</body>
</html>