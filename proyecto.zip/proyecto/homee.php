<!DOCTYPE html>
<html lang="es">

<head>
	<link rel="stylesheet"  href="css/estilos.css">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link href="css/style4.css" type="text/css" rel="stylesheet"/>
	<title>Home</title>
</head>
<body background="pictures/picture11.jpg" bgproperties="fixed">
<?php
	session_start();
	if(empty(isset($_GET['var']))){

	}
	else{
		$var=$_GET['var'];
		if ($var==1){
			session_destroy();
		}
	}

	if (empty($_SESSION['login'])){

// if Si $_Session esta vacia =======================================================================================
		?>
		<nav>
		    <ul>

		        <li>
		            <a href="registrar.php"><h4>Registrate</h4></a>
		        </li>
		        <li >
		            <a href="login.php?var=0"><h4>Accede a tu cuenta</h4></a>
		        </li>

		    </ul>
		</nav>

		</br> </br>
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-3">
					<table>
						<tr>
							<td>
								<img src="pictures/picture15.jpg"border="0" width="150" height="100">
							</td>
						</tr>
					</table>			
				</div>
	<!-- ==================================================================================================================== -->
				<div class="col-md-6">
					<form action="homeeb.php" method="POST">
						<table class="table table-striped" >
							<tr>
								<td>
									<label>Buscar archivo</label>
								</td>
								<td>
									<input type="text" name="txtbuscar" value="buscar" size="15" onclick="if(this.value=='buscar') this.value=''" onblur="if(this.value=='') this.value='buscar'">
								</td>
								<td>
									<select name="option" onChange="combo(this, 'theinput')">
										<option value="Musica">Musica</option>
									  	<option value="Videos">Video</option>
									  	<option value="Fotos">Photo</option>
									</select>
								</td>
								<td>
									<input type="submit" value="Buscar">
								</td>
							</tr>

						</table>					
					</form>			
				</div>
	<!-- ==================================================================================================================== -->
			
			</div>		
		</div>
	<?php
	}
// En if session inactiva ===================================================================================
	else{
		header("location: home.php?var=0");
	}
?>
</body>
</html>