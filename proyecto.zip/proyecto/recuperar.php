<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">	
	<title>Registrar</title>
	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrapValidator.min.js"></script>
	<script src="js/noty.js"></script>
	<script src="js/app.js"></script>
</head>
<body background="pictures/picture11.jpg" bgproperties="fixed">
<?php
  
	session_start();
	if (empty($_SESSION['login'])){		
		?>
	  <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
	  </br></br>
	    <div class="container-fluid" class="modal-dialog">
	      <div class="modal-content">
	          <div class="modal-body">
	              <div class="row">
	                <div class="col-xs-4"><img src="pictures/picture7.jpg " width="526" height="396"></div>
	                <div class="col-xs-1"></div>
	                  <div class="col-xs-4">
	                      <div class="well">
	                          <form  action="recuperar.php ? var=1" method="POST" id="form-login">
	                              <div class="form-group">
		                              <table class="table">
		                              	<tr>
		                              		<td><label for="nombre" class="control-label">Nombre</label></td>
		                              		<td><input type="text" name="nombre" class="form-control"></td>
		                              	</tr>
		                              	<tr>
											<td><label for="apellido" class="control-label">Apellido</label></td>
		                              		<td><input type="text" name="apellido" class="form-control"></td>
										</tr>
										<tr>
											<td><label for="correo" class="control-label">Correo</label></td>
		                              		<td><input type="text" name="correo" class="form-control"></td>
										</tr>
										<tr>
											<td><label for="usuario" class="control-label">Usuario</label></td>
		                              		<td><input type="text" name="user" class="form-control"></td>
										</tr>								
		                              </table>
	   
	                              </div>
	                              <button type="submit" class="btn btn-success btn-block">Registrar</button>
	                          </form>
	                      </div>
	                  </div>
	<!-- =================================================================================================================================== -->
					  <div class="col-xs-3">
                      	
                      	
                      <?php
                      if(empty(isset($_GET['var']))){

						}
						else{
							$var=$_GET['var'];
							if ($var==1){
								$Nombre=$_POST['nombre'];
							    $Apellido=$_POST['apellido'];
							    $Correo=$_POST['correo'];
							    $Usuario=$_POST['user'];	

							    $conection =mysql_connect('localhost','root');
					    		mysql_select_db("Files",$conection);	

					    		$consulta="SELECT *FROM  usuario where Nombre='$Nombre' and Apellido='$Apellido' and Correo= '$Correo' and Usuario='$Usuario'";	
								$datos = mysql_query($consulta);	

								if($datos[0]>0){
									?>
									<p class="lead">Datos<span class="text-success"></span></p>
									<?php 
									while ($record=mysql_fetch_row($datos)) {
										?>
										<ul class="list-unstyled" style="line-height: 2">
											<li><span class="fa fa-check text-success"></span> Nombre: <?php echo $record[1];?> </li>
		                          			<li><span class="fa fa-check text-success"></span> Apellido: <?php echo $record[2]; ?></li>
											<li><span class="fa fa-check text-success"></span> Correo: <?php echo $record[3];  ?> </li>
		                          			<li><span class="fa fa-check text-success"></span> Usuario: <?php echo $record[4]; ?></li>
		                          			<li><span class="fa fa-check text-success"></span> Contraseña: <?php echo $record[5]; ?></li>
		                          		</ul>
		                <?php
		                			}
								}
								else{
									?>
									<p class="lead">Los datos no son correctos<span class="text-success"></span></p>
									<?php
								}				
							}
						}

					  ?>
                      	
                  	  </div>
	<!-- =================================================================================================================================== -->
	              </div>
	          </div>
	      </div>
	  </div>
		<?php
	}
	else
		header("location: home.php?var=0");
?>

</body>
</html>
<!-- ================================== -->

<!-- ================================== -->
